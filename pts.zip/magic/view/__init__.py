from __future__ import absolute_import

from .ztv_api import MagicViewer
from .__about__ import __version__